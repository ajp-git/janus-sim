# Janus v5 → v6 patches

Génération: 2026-04-20, après analyse complète du run v5 (snap 0 à 5280, z=10→0.42)
qui a montré v_rms→0.33c, ρ_max→3.6e19, corr(δ+,δ−) positive à +0.80, N_stars=0.

## Fichiers

- `janus_adaptive_zoom.rs` — binaire principal, 5 bugs corrigés
- `snapshot_analyzer.py` — script d'analyse, 1 bug corrigé
- `janus_adaptive_zoom.patch` — diff unifié contre v5
- `snapshot_analyzer.patch` — diff unifié contre v5

## Bugs corrigés

### BUG #5 — proportion m+/m− et masses (src/bin/janus_adaptive_zoom.rs)

**Symptôme** : Zel'dovich produisait 52% de m+ (5.17M particules) au lieu de 5% (497k),
et `compute_particle_masses` attribuait m− = 19 × m+, donnant Ω_tot effectif ≈ 9.6 au lieu
de 1. Dynamique N-corps non affectée (kernel travaille en masses=1.0 adim) mais toutes
les densités reportées en M☉/Mpc³ étaient fausses d'un facteur ≈10, et les seuils de split
(`delta_split[0] = 10⁴ × ρ_mean_plus`) déclenchaient 10× trop tôt.

**Correction** :
- `compute_particle_masses` : `m+ = m- = Ω_b ρ_crit L³ (1+μ) / N_total`, masses **identiques**.
- `generate_zeldovich_ics` prend μ en paramètre, fait un shuffle déterministe (seed = SEED_IC + 12345)
  pour placer N/(1+μ) particules m+ et μN/(1+μ) particules m−.
- Convention conforme à `src/ic_gen.rs` et aux runs antérieurs (Corr=−0.072 validé).

### BUG #2 — Double conversion d'unités dans le cooling

**Symptôme** : `upload_densities` recevait des valeurs déjà converties en cm⁻³, mais le kernel
CUDA leur appliquait `rho_to_nh ≈ 3.1e−17` pour les reconvertir (attend du M☉/Mpc³).
Résultat : nH effectif ~3×10⁻¹⁷ fois trop petit, seuil SF (0.1 cm⁻³) jamais atteint,
N_stars = 0 dans tout le run v5.

**Correction** : `densities[i] = overdensities[i] × Ω_b × ρ_crit_0 × (1+z)³` en M☉/Mpc³.
Le kernel applique ensuite `rho_to_nh` pour obtenir nH.

### BUG #3 — Reset thermique à chaque split

**Symptôme** : à chaque événement de split (tous les 50 steps quand ρ dépasse seuil),
`gpu_cooling` était recréé et `init_from_temperature(T=10000 K)` rappelé, effaçant
toute l'histoire thermique. 28 événements de split entre z=0.71 et z=0.42 → équivalent
à désactiver le cooling dans les zones denses (celles où il matter).

**Correction** :
- `adaptive_split_check_with_thresholds` prend `u_plus_old: &[f64]` et retourne
  `(usize, Vec<f64>)` : le nouveau vecteur d'énergies internes aligné avec l'ordre
  m+ post-split. Chaque fille hérite de l'énergie du parent.
- Au site d'appel : `u_old = gpu_cooling.get_internal_energy()` avant drop,
  `gpu_cooling.set_internal_energy(&u_new)` après recréation.
- Logique swap_remove + particle_to_u.pop validée par port Python + 100 tests aléatoires.

### BUG #4 — SFR et N_stars non transmis aux snapshots

**Symptôme** : `save_snapshot(..., 0, 0.0, rho_max)` hardcodait n_stars=0 et sfr=0 dans
les headers v3, masquant la SF si elle existait. Warnings `unused_assignments` du compilateur.

**Correction** : `save_snapshot(..., n_stars as u64, sfr, rho_max)`.

### BUG #1 — Corrélation δ+,δ− biaisée par splitting (scripts/snapshot_analyzer.py)

**Symptôme** : histogrammes 3D de particules → un m+ splitté en 8 filles comptait 8×
dans sa cellule. Halos m+ denses = corrélés par construction avec la présence de m− qui
y sont tombées. Résultat : corr(δ+,δ−) passait de −0.07 (avant splits) à +0.80 (après).

**Correction** : `compute_segregation` accepte `mass_plus`, `mass_minus` et utilise
`np.histogramdd(..., weights=masses)`. Les champs δ+ et δ− représentent désormais
la vraie surdensité de masse, invariante sous splitting. Validé sur scénario synthétique
(même corr avant/après splits).

## Validation effectuée SANS toolchain Rust

- Relecture ligne-par-ligne des 5 patches.
- Port Python de la logique du patch #3 + 6 tests unitaires incluant 100 stress tests
  aléatoires → **tous passent**.
- Vérification analytique du patch #2 : avec le patch, à z=5 od=1, nH ≈ 4.5e−5 cm⁻³
  (cohérent avec n_baryon physique). Seuil SF (nH>0.1) atteint pour od > 360 à z=10,
  > 5e5 à z=0 — compatible avec les cores denses du run v5 (od_pic ≈ 10⁵).
- Vérification analytique du patch #5 : Ω_tot = 1.000 après correction (vs 9.64 avant).
- Vérification analytique du patch #1 : corr invariante sous splitting avec pondération
  par masse (Δ = 0.0000 vs 0.0082 sans patch).

## CE QUI RESTE À FAIRE AVANT RELANCE 30h

1. **`cargo check --bin janus_adaptive_zoom --features cuda`** — il faut vérifier
   que la compilation passe, je n'ai pas pu le faire.
2. **`cargo build --release --bin janus_adaptive_zoom --features cuda`**
3. **Run de validation court** (20-30 min) :
   ```
   cargo run --release --features cuda --bin janus_adaptive_zoom -- \
     --n-grid 50 --l-box 200 --z-init 10 --z-final 3 \
     --steps-check 20 --snap-interval 20 \
     --out-dir output/v6_test --run-label v6_test
   ```
   Critères de succès :
   - Pas de panic sur assert_eq!(n_plus_new, u_new.len())
   - Log "Sign assignment (Janus, μ=19): N+ = N/(1+μ) = 6250" (125000/20)
   - Ω_tot reconstruit depuis snapshot header ≈ 1.00 ± 1%
   - Après premier split : log "Split +N particules" puis run continue sans explosion v_rms
   - Un snapshot au moins avec n_stars > 0 (log "★ Step XXXX: N nouvelles étoiles")
   - `corr_delta` calculé par snapshot_analyzer.py sur le dernier snap → négative
     (ou au moins < 0.3, indiquant ségrégation partielle)

4. Si tous les critères ci-dessus passent → relance production full 215³ → z=0.

## Points NON patchés (par choix)

- `compute_local_overdensities` utilise grid_size=32 (cell=15.6 Mpc). Cela limite la
  résolution des overdensités mesurées par le cooling à ~10⁴. SF se déclenchera uniquement
  dans les cores très denses. Peut être augmenté (grid_size=64 ou 128) dans un run futur.
- `compute_densities` L420-463 : même grid 64³ hardcodé. OK pour v5.
- Le G_COSMO = 4.499e-15 déclaré const et jamais utilisé dans le binaire : c'est un
  résidu. Pas un bug actif (le kernel utilise G=1 adim). Laissé en place.
