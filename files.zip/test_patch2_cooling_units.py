"""Valide le patch #2 : la densité passée au kernel est maintenant en M☉/Mpc³
et donne le bon nH après multiplication par rho_to_nh."""

# Constantes du kernel (cooling_gpu.rs L80-84)
msun_g = 1.989e33
mpc_cm = 3.086e24
mp_g = 1.6726e-24
x_h = 0.76
rho_to_nh = msun_g / (mpc_cm**3) * x_h / mp_g

print(f"rho_to_nh kernel = {rho_to_nh:.4e}  (M☉/Mpc³ -> nH cm⁻³)")

# Cas : galaxie moderne, overdensité 1000 (core d'un halo), z=5
z = 5.0
overdensity = 1000.0
H0 = 69.9
omega_b = 0.05

# AVANT patch (code original)
rho_mean_0_cgs = 9.47e-30  # g/cm³ (ρ_crit_0)
nH_mean_old = rho_mean_0_cgs * omega_b * (1.0 + z)**3 * x_h / mp_g
density_passed_old = overdensity * nH_mean_old  # en cm⁻³
nH_in_kernel_old = density_passed_old * rho_to_nh  # ce que voit le kernel
print(f"\nAVANT patch:")
print(f"  nH_mean à z={z}: {nH_mean_old:.4e} cm⁻³")
print(f"  density envoyée: {density_passed_old:.4e} cm⁻³")
print(f"  nH kernel: {nH_in_kernel_old:.4e} cm⁻³")
print(f"  → Seuil SF (~0.1 cm⁻³): {'ATTEINT' if nH_in_kernel_old > 0.1 else 'JAMAIS atteint'}")

# APRÈS patch
rho_crit_0 = 2.775e11 * (H0/100)**2  # M☉/Mpc³
rho_mean_b_z_new = omega_b * rho_crit_0 * (1.0 + z)**3  # M☉/Mpc³
density_passed_new = overdensity * rho_mean_b_z_new  # M☉/Mpc³
nH_in_kernel_new = density_passed_new * rho_to_nh
print(f"\nAPRÈS patch:")
print(f"  rho_mean_b à z={z}: {rho_mean_b_z_new:.4e} M☉/Mpc³")
print(f"  density envoyée: {density_passed_new:.4e} M☉/Mpc³")
print(f"  nH kernel: {nH_in_kernel_new:.4e} cm⁻³")
print(f"  → Seuil SF (~0.1 cm⁻³): {'ATTEINT' if nH_in_kernel_new > 0.1 else 'JAMAIS atteint'}")

# Vérif physique : ρ_baryon à overdensité 1, z=5, devrait donner nH physiquement raisonnable
nH_baryon_physical_z5_od1 = 1 * rho_mean_b_z_new * rho_to_nh
# Attendu : nH(z=5, od=1) = n_baryon(z=5) = n_H,0 * (1+z)^3 avec n_H,0 ≈ 1.6e-7 cm⁻³
# → à z=5 : 1.6e-7 * 216 ≈ 3.5e-5 cm⁻³
print(f"\nVérif physique: nH à od=1, z=5 (attendu ~3.5e-5 cm⁻³)")
print(f"  calculé: {nH_baryon_physical_z5_od1:.4e} cm⁻³")
print(f"  → ordre de grandeur: {'OK' if 1e-6 < nH_baryon_physical_z5_od1 < 1e-3 else 'SUSPECT'}")
