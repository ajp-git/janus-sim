"""Port Python de adaptive_split_check_with_thresholds + test de cohérence u.

Réplique exactement la logique Rust du patch #3 pour valider que l'énergie
interne est correctement propagée à travers swap_remove + extend.
"""
import random

class Particle:
    __slots__ = ('id', 'sign', 'split_level', 'density')
    def __init__(self, pid, sign, split_level=0, density=0.0):
        self.id = pid
        self.sign = sign
        self.split_level = split_level
        self.density = density
    def __repr__(self):
        return f"P(id={self.id},sign={self.sign:+},lvl={self.split_level})"

def adaptive_split(particles, densities, threshold, u_plus_old):
    """Réplique exacte du Rust patch #3."""
    # Build initial mapping m+ index -> u index
    particle_to_u = [-1] * len(particles)
    k = 0
    for i, p in enumerate(particles):
        if p.sign == 1:
            if k < len(u_plus_old):
                particle_to_u[i] = k
            k += 1

    # Find to_split
    to_split = []
    for i, p in enumerate(particles):
        if p.sign != 1: continue
        if p.split_level >= 9: continue
        if densities[i] > threshold:
            to_split.append(i)

    if not to_split:
        return 0, list(u_plus_old)

    # Create daughters
    new_particles = []
    new_particle_u = []
    next_id = max(p.id for p in particles) + 1
    for idx in reversed(to_split):
        parent = particles[idx]
        parent_u_idx = particle_to_u[idx]
        parent_u = u_plus_old[parent_u_idx] if (0 <= parent_u_idx < len(u_plus_old)) else 0.0
        for _d in range(8):
            new_particles.append(Particle(
                pid=next_id,
                sign=parent.sign,
                split_level=parent.split_level + 1,
                density=0.0
            ))
            next_id += 1
            new_particle_u.append(parent_u)

    # swap_remove in reverse order, keeping particle_to_u in sync
    for idx in reversed(to_split):
        last = len(particles) - 1
        # swap_remove
        particles[idx] = particles[last]
        particles.pop()
        if idx != last:
            particle_to_u[idx] = particle_to_u[last]
        particle_to_u.pop()

    # extend daughters
    particles.extend(new_particles)
    n_new = len(new_particles)

    # Build u_new
    n_preserved = len(particles) - n_new
    u_new = []
    for i in range(n_preserved):
        p = particles[i]
        if p.sign == 1:
            u_idx = particle_to_u[i]
            if 0 <= u_idx < len(u_plus_old):
                u_new.append(u_plus_old[u_idx])
            else:
                u_new.append(0.0)
    for u in new_particle_u:
        u_new.append(u)

    return n_new, u_new


def verify(particles, u_new, initial_u_by_pid, parent_pid_for_daughter):
    """Vérifie que u_new[k] correspond bien à l'énergie attendue du k-e m+ de particles."""
    m_plus_particles = [p for p in particles if p.sign == 1]
    assert len(m_plus_particles) == len(u_new), f"len mismatch: {len(m_plus_particles)} m+ vs {len(u_new)} u"

    for k, p in enumerate(m_plus_particles):
        if p.id in initial_u_by_pid:
            expected = initial_u_by_pid[p.id]
        else:
            # It's a daughter
            parent_pid = parent_pid_for_daughter[p.id]
            expected = initial_u_by_pid[parent_pid]
        assert abs(u_new[k] - expected) < 1e-12, \
            f"u mismatch at k={k} (pid={p.id}): got {u_new[k]}, expected {expected}"
    return True


# ============================================================================
# TEST CASES
# ============================================================================

def test_no_split():
    """Pas de split => u_new == u_plus_old exactement."""
    particles = [Particle(0, +1), Particle(1, -1), Particle(2, +1), Particle(3, -1), Particle(4, +1)]
    densities = [1.0, 1.0, 1.0, 1.0, 1.0]
    u_old = [100.0, 200.0, 300.0]  # 3 m+
    n_new, u_new = adaptive_split(particles, densities, threshold=10.0, u_plus_old=u_old)
    assert n_new == 0
    assert u_new == u_old
    print("TEST 1 (no split): OK")

def test_single_split():
    """Un seul m+ dépasse le seuil."""
    particles = [Particle(0, +1), Particle(1, -1), Particle(2, +1), Particle(3, -1), Particle(4, +1)]
    densities = [1.0, 1.0, 99.0, 1.0, 1.0]  # particule id=2 (le 2e m+, donc u_idx=1) dépasse
    u_old = [100.0, 200.0, 300.0]
    initial_u_by_pid = {0: 100.0, 2: 200.0, 4: 300.0}  # m+ pids: 0,2,4 -> u[0,1,2]

    n_new, u_new = adaptive_split(list(particles), densities, threshold=10.0, u_plus_old=u_old)

    # Rebuild particles pour vérif (copier)
    particles_after = list(particles)
    densities_after = list(densities)
    n_new2, u_new2 = adaptive_split(particles_after, densities_after, threshold=10.0, u_plus_old=u_old)

    assert n_new2 == 8
    # 2 m+ préservés (id=0 et id=4) + 8 filles (parent id=2, u=200)
    # Ordre après swap_remove de idx=2 (len=5, last=4):
    #   Before: [P0+, P1-, P2+, P3-, P4+]
    #   After swap_remove(2): [P0+, P1-, P4+, P3-] (P4+ moved to idx 2)
    #   extend 8 daughters: [P0+, P1-, P4+, P3-, D5+, D6+, D7+, D8+, D9+, D10+, D11+, D12+]
    # m+ dans l'ordre: P0, P4, D5, D6, D7, D8, D9, D10, D11, D12
    # u attendu: [100 (P0), 300 (P4), 200, 200, 200, 200, 200, 200, 200, 200]
    parent_for_daughter = {pid: 2 for pid in range(5, 13)}
    ok = verify(particles_after, u_new2, initial_u_by_pid, parent_for_daughter)
    assert ok

    expected = [100.0, 300.0] + [200.0]*8
    assert u_new2 == expected, f"Got {u_new2}, expected {expected}"
    print("TEST 2 (single split middle m+): OK")

def test_split_at_end():
    """m+ en dernière position split -> swap_remove dégénère (idx == last)."""
    particles = [Particle(0, +1), Particle(1, -1), Particle(2, +1), Particle(3, -1), Particle(4, +1)]
    densities = [1.0, 1.0, 1.0, 1.0, 99.0]  # dernier m+ (id=4, u_idx=2)
    u_old = [100.0, 200.0, 300.0]

    n_new, u_new = adaptive_split(particles, densities, threshold=10.0, u_plus_old=u_old)
    assert n_new == 8
    # Ordre: swap_remove(4) = pop last => [P0+, P1-, P2+, P3-]
    # + 8 filles parent u=300
    # m+ après: P0, P2, D..
    expected = [100.0, 200.0] + [300.0]*8
    assert u_new == expected, f"Got {u_new}, expected {expected}"
    print("TEST 3 (split last m+): OK")

def test_multiple_splits():
    """Plusieurs m+ splittent simultanément."""
    # 10 particules, alternant +/-
    particles = [Particle(i, +1 if i%2==0 else -1) for i in range(10)]
    # m+ aux pids 0,2,4,6,8 (u_idx 0..4)
    # Faisons splitter les pids 2 et 6
    densities = [0, 0, 99, 0, 0, 0, 99, 0, 0, 0]
    u_old = [10.0, 20.0, 30.0, 40.0, 50.0]  # u pour m+ [0,2,4,6,8]

    n_new, u_new = adaptive_split(particles, densities, threshold=50.0, u_plus_old=u_old)
    assert n_new == 16  # 2 splits × 8

    # Trace manuelle:
    # to_split = [2, 6], iter reversed: 6, 2
    # Iteration idx=6: last=9. swap_remove(6) => P[6]=P[9], len=9.
    #   Before: [P0+,P1-,P2+,P3-,P4+,P5-,P6+,P7-,P8+,P9-]
    #   After:  [P0+,P1-,P2+,P3-,P4+,P5-,P9-,P7-,P8+]  (len=9)
    # Iteration idx=2: last=8. swap_remove(2) => P[2]=P[8]=P8+, len=8.
    #   After:  [P0+,P1-,P8+,P3-,P4+,P5-,P9-,P7-]  (len=8)
    # Extend 16 daughters:
    #   [P0+,P1-,P8+,P3-,P4+,P5-,P9-,P7-,D...x8(parent=6),D...x8(parent=2)]
    #
    # u_plus_old mapping:
    #   P0 -> 10, P2 -> 20, P4 -> 30, P6 -> 40, P8 -> 50
    # u pour m+ préservés dans l'ordre [P0, P8, P4]:
    #   P0 -> 10, P8 -> 50, P4 -> 30
    # u pour filles (ordre iter reversed sur to_split => d'abord parent id=6 puis parent id=2):
    #   8× 40, 8× 20
    expected = [10.0, 50.0, 30.0] + [40.0]*8 + [20.0]*8
    assert u_new == expected, f"Got {u_new}, expected {expected}"
    print("TEST 4 (multiple splits): OK")

def test_all_m_plus_split():
    """Cas extrême : tous les m+ splittent."""
    particles = [Particle(0, +1), Particle(1, -1), Particle(2, +1), Particle(3, +1)]
    densities = [99, 0, 99, 99]
    u_old = [11.0, 22.0, 33.0]  # pour pids 0, 2, 3

    n_new, u_new = adaptive_split(particles, densities, threshold=10.0, u_plus_old=u_old)
    assert n_new == 24  # 3 splits × 8

    # to_split = [0, 2, 3], reversed: 3, 2, 0
    # idx=3, last=3: swap_remove(3) = pop => [P0+,P1-,P2+] (len=3)
    # idx=2, last=2: swap_remove(2) = pop => [P0+,P1-] (len=2)
    # idx=0, last=1: swap_remove(0) => P[0]=P[1]=P1- => [P1-] (len=1)
    # Extend 24 daughters: [P1-, D(p=3)x8, D(p=2)x8, D(p=0)x8]
    # m+ dans l'ordre: D(p=3)x8, D(p=2)x8, D(p=0)x8
    expected = [33.0]*8 + [22.0]*8 + [11.0]*8
    assert u_new == expected, f"Got {u_new}, expected {expected}"
    print("TEST 5 (all m+ split): OK")

def test_random_stress():
    """Stress test avec configurations aléatoires."""
    random.seed(42)
    for trial in range(100):
        n = random.randint(10, 200)
        particles = []
        initial_u_by_pid = {}
        u_old = []
        pid = 0
        for _ in range(n):
            sign = random.choice([+1, -1])
            particles.append(Particle(pid, sign, split_level=random.randint(0,2)))
            if sign == 1:
                u = random.uniform(1e3, 1e5)
                initial_u_by_pid[pid] = u
                u_old.append(u)
            pid += 1

        densities = [random.uniform(0, 100) for _ in range(n)]
        threshold = 50.0

        # Quelles m+ vont splitter ?
        expected_split_pids = set()
        for i, p in enumerate(particles):
            if p.sign == 1 and p.split_level < 9 and densities[i] > threshold:
                expected_split_pids.add(p.id)

        particles_copy = list(particles)
        n_new, u_new = adaptive_split(particles_copy, densities, threshold, u_old)

        # Vérifier longueur
        n_m_plus_after = sum(1 for p in particles_copy if p.sign == 1)
        assert n_m_plus_after == len(u_new), f"Trial {trial}: {n_m_plus_after} m+ vs {len(u_new)} u"

        # Construire mapping daughter -> parent
        n_preserved = len(particles_copy) - n_new
        daughters = particles_copy[n_preserved:]
        # Les filles sont créées dans l'ordre reversed(to_split), donc dans l'ordre décroissant d'idx
        # original. Mais on n'a plus accès aux indices originaux... on utilise les pids.
        # Reconstruire: les pids des filles commencent après max(pid initial)
        # Plus simple: vérifier que chaque u_new correspond à un u initial existant
        for k, u in enumerate(u_new):
            p = [x for x in particles_copy if x.sign == 1][k]
            if p.id in initial_u_by_pid:
                assert abs(u - initial_u_by_pid[p.id]) < 1e-12
            else:
                # fille - u doit être égal à u d'un parent qui a splitté
                assert any(abs(u - initial_u_by_pid[pid_s]) < 1e-12 for pid_s in expected_split_pids)

    print(f"TEST 6 (stress 100 random configs): OK")


if __name__ == '__main__':
    test_no_split()
    test_single_split()
    test_split_at_end()
    test_multiple_splits()
    test_all_m_plus_split()
    test_random_stress()
    print("\n✅ All patch #3 logic tests passed")
