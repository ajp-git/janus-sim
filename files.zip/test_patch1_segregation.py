"""Valide le patch #1 (pondération par masse) sur un cas synthétique
qui reproduit le biais splitting."""
import numpy as np

def compute_segregation_old(pos_plus, pos_minus, l_box, grid_size=64):
    """Version originale, sans pondération."""
    half = l_box / 2.0
    bins = np.linspace(-half, half, grid_size + 1)
    hist_plus, _ = np.histogramdd(pos_plus, bins=[bins, bins, bins])
    hist_minus, _ = np.histogramdd(pos_minus, bins=[bins, bins, bins])
    mean_p = np.mean(hist_plus); mean_m = np.mean(hist_minus)
    if mean_p > 0 and mean_m > 0:
        delta_p = (hist_plus - mean_p) / mean_p
        delta_m = (hist_minus - mean_m) / mean_m
        corr = np.corrcoef(delta_p.flatten(), delta_m.flatten())[0, 1]
        return 0.0 if np.isnan(corr) else corr
    return 0.0

def compute_segregation_new(pos_plus, pos_minus, l_box, grid_size=64, mass_plus=None, mass_minus=None):
    """Version patchée : pondération par masses."""
    half = l_box / 2.0
    bins = np.linspace(-half, half, grid_size + 1)
    wp = mass_plus if mass_plus is not None else None
    wm = mass_minus if mass_minus is not None else None
    hist_plus, _ = np.histogramdd(pos_plus, bins=[bins, bins, bins], weights=wp)
    hist_minus, _ = np.histogramdd(pos_minus, bins=[bins, bins, bins], weights=wm)
    mean_p = np.mean(hist_plus); mean_m = np.mean(hist_minus)
    if mean_p > 0 and mean_m > 0:
        delta_p = (hist_plus - mean_p) / mean_p
        delta_m = (hist_minus - mean_m) / mean_m
        corr = np.corrcoef(delta_p.flatten(), delta_m.flatten())[0, 1]
        return 0.0 if np.isnan(corr) else corr
    return 0.0


# ============================================================================
# SCÉNARIO SYNTHÉTIQUE REPRODUISANT LE BIAIS
# ============================================================================
np.random.seed(42)
L = 500.0
half = L/2

# Cas A : sans splits, univers Janus ségrégé (ce qu'on attend des runs non-adaptatifs)
# m+ et m- dans des régions différentes
N_plus = 100_000
N_minus = 100_000

# m+ concentrés autour de (100, 0, 0) avec dispersion, et quelques "halos" petits
pos_plus_A = np.random.randn(N_plus, 3) * 50
pos_plus_A[:, 0] += 100  # décalage

# m- concentrés autour de (-100, 0, 0)
pos_minus_A = np.random.randn(N_minus, 3) * 50
pos_minus_A[:, 0] -= 100

# clamp
pos_plus_A = np.clip(pos_plus_A, -half+1, half-1)
pos_minus_A = np.clip(pos_minus_A, -half+1, half-1)

# Toutes masses égales (pas de split)
mass_plus_A = np.ones(N_plus) * 1.7e12
mass_minus_A = np.ones(N_minus) * 1.7e12

corr_A_old = compute_segregation_old(pos_plus_A, pos_minus_A, L, 64)
corr_A_new = compute_segregation_new(pos_plus_A, pos_minus_A, L, 64, mass_plus_A, mass_minus_A)
print(f"Cas A (ségrégé, pas de splits):")
print(f"  corr_old = {corr_A_old:+.4f}")
print(f"  corr_new = {corr_A_new:+.4f}")
print(f"  → identiques (pas de splits) ✓")

# Cas B : MÊME physique sous-jacente, mais avec 80% des m+ du halo principal splittés
# en 8 filles (comme dans v5). Une particule m+ sur 5 devient 8 filles → ratio 8/5 = 1.6× plus de comptage
# dans les zones denses.
# On simule ça : dans la zone dense m+ (disons r < 20 Mpc du centre m+), chaque m+ est remplacée par 8 filles
center_p = np.array([100, 0, 0])
dist_p = np.linalg.norm(pos_plus_A - center_p, axis=1)
dense_mask = dist_p < 20.0
print(f"\n  {np.sum(dense_mask)} m+ dans la zone dense (20 Mpc du centre)")

# Nouvelles particules : filles à la place des dense
pos_plus_dense = pos_plus_A[dense_mask]
# 8 filles par parent, petite dispersion
n_split = np.sum(dense_mask)
pos_plus_daughters = np.repeat(pos_plus_dense, 8, axis=0)
pos_plus_daughters += np.random.randn(8*n_split, 3) * 0.05  # jitter tiny

# Autres m+ restent
pos_plus_B = np.concatenate([pos_plus_A[~dense_mask], pos_plus_daughters], axis=0)
# Masses : m+/8 pour les filles, m+ base pour les autres
mass_plus_B = np.concatenate([
    np.ones(np.sum(~dense_mask)) * 1.7e12,
    np.ones(8*n_split) * 1.7e12 / 8
])

pos_minus_B = pos_minus_A.copy()
mass_minus_B = mass_minus_A.copy()

corr_B_old = compute_segregation_old(pos_plus_B, pos_minus_B, L, 64)
corr_B_new = compute_segregation_new(pos_plus_B, pos_minus_B, L, 64, mass_plus_B, mass_minus_B)
print(f"\nCas B (MÊME physique, avec splits adaptatifs):")
print(f"  N_m+ = {len(pos_plus_B):,} (au lieu de {N_plus:,})")
print(f"  corr_old = {corr_B_old:+.4f}")
print(f"  corr_new = {corr_B_new:+.4f}")
print(f"  → Le patch doit donner corr_new ≈ corr_A_new (même physique)")
print(f"  Diff patch: |corr_new - corr_A_new| = {abs(corr_B_new - corr_A_new):.4f}")
print(f"  Diff sans patch: |corr_old - corr_A_old| = {abs(corr_B_old - corr_A_old):.4f}")

if abs(corr_B_new - corr_A_new) < abs(corr_B_old - corr_A_old):
    print("\n✅ Patch #1 corrige bien le biais splitting")
else:
    print("\n❌ Patch #1 ne semble pas corriger")
